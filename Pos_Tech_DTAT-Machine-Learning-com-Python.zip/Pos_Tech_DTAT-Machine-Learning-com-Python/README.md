# Pos_Tech_DTAT
Repositório para todas as Fases contemplando os códigos utilizados nas disciplinas da Pós Tech em Data Analytics
